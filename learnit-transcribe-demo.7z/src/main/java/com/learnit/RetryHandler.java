package com.learnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import com.amazonaws.services.lambda.runtime.events.SNSEvent;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.event.S3EventNotification;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.S3Object;

public class RetryHandler implements RequestHandler<SNSEvent, String> {
	private static final Logger LOG = LogManager.getLogger(RetryHandler.class);
	private AmazonS3 s3Client = AmazonS3ClientBuilder.standard().withRegion("us-east-1").build();
	@Override
	public String handleRequest(SNSEvent snsEvent, Context context) {

		S3EventNotification s3EventNotification = S3EventNotification.parseJson(snsEvent.getRecords().get(0).getSNS().getMessage());
	    S3EventNotification.S3EventNotificationRecord record = s3EventNotification.getRecords().get(0);

		String srcBucket = record.getS3().getBucket().getName();
		// Object key may have spaces or unicode non-ASCII characters.
		String srcKey = record.getS3().getObject().getUrlDecodedKey();

		String erroredFilesBucket = "learnit-transcribe-errored-files-bucket";
	   S3Object s3Object = s3Client.getObject(srcBucket, srcKey);
	   boolean isDeleted = false;
		try {

			ObjectMetadata metadata = s3Object.getObjectMetadata();

			if(null != metadata.getUserMetadata() && metadata.getUserMetadata().containsKey("retryCount")) {
				// Retry Count Exists, Check Count and Proceed
				int count = Integer.parseInt(metadata.getUserMetadata().get("retryCount"));
				if(count<5) {
					// Retry to process this event
					LOG.info("Retry Count : " + count);
                    metadata.getUserMetadata().put("retryCount", Integer.toString(count+1));
					s3Client.putObject(srcBucket, srcKey, s3Object.getObjectContent().getDelegateStream(), metadata); 
				} else {
					// Retry limit reached, move to errored files bucket
					LOG.info("Custom Retry limit exhausted, Moving file to errored bucket");
					s3Client.copyObject(srcBucket, srcKey, erroredFilesBucket, srcKey);
					
					// Delete Object from actual location
				    s3Client.deleteObject(srcBucket, srcKey);
					isDeleted =true;
				}
			} else {
				//Initialize Retrycount
				metadata.addUserMetadata("retryCount", "1");
				LOG.info("Initialized Object's UserMetaData, Retry Count : 1");
				s3Client.putObject(srcBucket, srcKey, s3Object.getObjectContent().getDelegateStream(), metadata);
			}
			return "Ok";
		} catch (Exception e) {
			LOG.error("Failed to retry sns event : ", snsEvent, e);
			return null;
		} finally {
			try {
				if(!isDeleted)
				s3Object.close();
			} catch (IOException e) {
				LOG.error("Failed to close s3 object for snsevent : ", snsEvent, e);
			}
		}
	}
}
