package com.learnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.S3Event;
import com.amazonaws.services.lambda.runtime.events.models.s3.S3EventNotification.S3EventNotificationRecord;
import com.amazonaws.services.transcribe.AmazonTranscribe;
import com.amazonaws.services.transcribe.AmazonTranscribeClientBuilder;
import com.amazonaws.services.transcribe.model.Media;
import com.amazonaws.services.transcribe.model.StartTranscriptionJobRequest;

public class S3Handler implements RequestHandler<S3Event, String> {
	private static final Logger LOG = LogManager.getLogger(S3Handler.class);
	@Override
	public String handleRequest(S3Event s3event, Context context) {

		try {
			S3EventNotificationRecord record = s3event.getRecords().get(0);
			String srcBucket = record.getS3().getBucket().getName();
			// Object key may have spaces or unicode non-ASCII characters.
			String srcKey = record.getS3().getObject().getUrlDecodedKey();

			AmazonTranscribe amazonTranscribe = AmazonTranscribeClientBuilder.standard().withRegion("us-east-1")
					.build();

			StartTranscriptionJobRequest startTranscriptionJobRequest = new StartTranscriptionJobRequest();
			startTranscriptionJobRequest.setTranscriptionJobName(srcKey+"transcribeJob");
			startTranscriptionJobRequest.setMediaFormat("mp3");
			startTranscriptionJobRequest.setLanguageCode("en-US");

			Media media = new Media();
			media.setMediaFileUri("s3://" + srcBucket + "/" + srcKey);
			startTranscriptionJobRequest.setMedia(media);
			startTranscriptionJobRequest.setOutputBucketName(srcBucket);

			amazonTranscribe.startTranscriptionJob(startTranscriptionJobRequest);
			return "Ok";
		} catch (Exception e) {
			LOG.error("Failed to generate transcription for event : ", s3event, e);
			throw e;
		}
	}
}
