package com.learnit;

import java.util.Collections;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.GetItemSpec;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import com.amazonaws.xray.proxies.apache.http.HttpClientBuilder;

public class GetUserHandler implements RequestHandler<Map<String, Object>, ApiGatewayResponse> {

	private static final Logger LOG = LogManager.getLogger(GetUserHandler.class);

	@Override
	public ApiGatewayResponse handleRequest(Map<String, Object> input, Context context) {
		LOG.info("received: {}", input);
		Response responseBody = new Response("Go Serverless v1.x! Your function executed successfully!", input);

		makeHTTPCall();

		AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard().withRegion(Regions.US_EAST_1).build();

		DynamoDB dynamoDB = new DynamoDB(client);
		Table table = dynamoDB.getTable("players");

		GetItemSpec spec = new GetItemSpec().withPrimaryKey("email", "hitman47@gmail.com", "badge", "Diamond");

		try {
			LOG.info("Attempting to read the item...");
			Item outcome = table.getItem(spec);
			LOG.info("GetItem succeeded: " + outcome);
		} catch (Exception e) {
			LOG.debug(e.getMessage());
		}

		return ApiGatewayResponse.builder().setStatusCode(200).setObjectBody(responseBody)
				.setHeaders(Collections.singletonMap("X-Powered-By", "AWS Lambda & serverless")).build();
	}

	/**
	 * Sample Function to get Outgoing HTTP Calls Traces in AWX XRay.
	 */
	private void makeHTTPCall() {
		// XRay outgoing http calls
		// com.amazonaws.xray.proxies.apache.http.HttpClientBuilder Not apache
		// httpclientbuilder
		CloseableHttpClient httpclient = HttpClientBuilder.create().build();

		HttpGet httpGet = new HttpGet("https://gorest.co.in/public/v1/postss");
		CloseableHttpResponse response = null;
		try {
			response = httpclient.execute(httpGet);
			HttpEntity entity = response.getEntity();
			LOG.info("HTTP Call Response :" + EntityUtils.toString(entity));

		} catch (Exception e) {
			LOG.catching(e);
		} finally {
			if (null != response) {
				try {
					response.close();
				} catch (Exception e) {
					LOG.catching(e);
				}
			}
		}
	}
}
