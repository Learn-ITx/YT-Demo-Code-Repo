package com.learnit;

import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Map;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.AWSLambda;
import com.amazonaws.services.lambda.AWSLambdaClientBuilder;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.xray.AWSXRay;
import com.amazonaws.xray.entities.Subsegment;
import com.amazonaws.xray.proxies.apache.http.HttpClientBuilder;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class TestAwsXrayHandler implements RequestHandler<Map<String, Object>, ApiGatewayResponse> {

    private static final Logger LOG = LogManager.getLogger(TestAwsXrayHandler.class);

    @Override
    public ApiGatewayResponse handleRequest(Map<String, Object> input, Context context) {
        LOG.info("received: {}", input);
        Response responseBody = new Response("welcome to LearnIT!", input);

        makeHTTPCall();

        invokeLambdaFunction(input);

        return ApiGatewayResponse.builder().setStatusCode(200).setObjectBody(responseBody)
                .setHeaders(Collections.singletonMap("X-Powered-By", "AWS Lambda & serverless")).build();
    }

    /**
     * Sample Function to get other lambda calls Traces in AWX XRay.
     */
    private void invokeLambdaFunction(Map<String, Object> input) {
        // XRay Other Service Calls, lambda invoke
        InvokeResult invokeResult = null;

        try {
            InvokeRequest invokeRequest = new InvokeRequest().withFunctionName("xray-test-service-dev-getUserDetails")
                    .withPayload(new ObjectMapper().writeValueAsString(input));
            AWSLambda awsLambda = AWSLambdaClientBuilder.standard().withRegion(Regions.US_EAST_1).build();

            invokeResult = awsLambda.invoke(invokeRequest);

            String lambdaReponse = new String(invokeResult.getPayload().array(), StandardCharsets.UTF_8);

            LOG.info("Lambda Invoke Status Code : " + invokeResult.getStatusCode());
            LOG.info("lambda Reponse : " + lambdaReponse);

        } catch (Exception e) {
            LOG.catching(e);
        }
    }

    /**
     * Sample Function to get Outgoing HTTP Calls Traces in AWX XRay.
     */
    private void makeHTTPCall() {

        Subsegment subsegment = AWSXRay.beginSubsegment("makeHTTPCall function");
        // XRay outgoing http calls
        // com.amazonaws.xray.proxies.apache.http.HttpClientBuilder Not apache
        // httpclientbuilder
        CloseableHttpClient httpclient = HttpClientBuilder.create().build();

        HttpGet httpGet = new HttpGet("https://gorest.co.in/public/v1/users");
        CloseableHttpResponse response = null;
        try {
            response = httpclient.execute(httpGet);
            HttpEntity entity = response.getEntity();
            LOG.info("HTTP Call Response :" + EntityUtils.toString(entity));
            subsegment.putAnnotation("testAnnotationKey", "testAnnotationValue");
            subsegment.putMetadata("httpResponse", entity);
        } catch (Exception e) {
            LOG.catching(e);
        } finally {
            if (null != response) {
                try {
                    response.close();
                } catch (Exception e) {
                    LOG.catching(e);
                }
            }

            // close subsegment
            AWSXRay.endSubsegment();
        }
    }
}